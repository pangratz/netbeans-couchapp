function(doc, req) {
  
}