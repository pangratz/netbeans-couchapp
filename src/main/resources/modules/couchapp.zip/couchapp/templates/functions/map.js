function(doc) {
  
}