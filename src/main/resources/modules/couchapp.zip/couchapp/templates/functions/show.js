function(doc, req) {  
  
}