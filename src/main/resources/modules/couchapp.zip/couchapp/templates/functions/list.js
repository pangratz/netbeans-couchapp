function(head, req) {
  
}