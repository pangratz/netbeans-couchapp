function(doc, req) {

}