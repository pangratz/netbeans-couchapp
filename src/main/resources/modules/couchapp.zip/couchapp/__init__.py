# -*- coding: utf-8 -*-
#
# This file is part of couchapp released under the Apache 2 license. 
# See the NOTICE for more information.

version_info = (0, 7, 5)
__version__ =  ".".join(map(str, version_info))
