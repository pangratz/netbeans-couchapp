#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# This file is part of couchapp released under the Apache 2 license. 
# See the NOTICE for more information.

if __name__ == "__main__":
    from couchapp import dispatch
